package alphabeta;

import common.Constant;

//某一方的棋局数据
public class PositionStateMap {

	public PositionState[] positionState_array;  //一张表,与棋盘位置一一对应
	
	//进攻	
	public PositionLinkedList[] attack_node_list_array;  //用数组代替多个对象，也就不必用switch case if else判断了
	
	//防御
	public PositionLinkedList[] defense_node_list_array;
	
	public PositionStateMap() {
		this(Constant.POSITION_LINKED_LIST_MAX_SIZE);
	}
	
	public PositionStateMap(int len) {		
		attack_node_list_array = new PositionLinkedList[Constant.POSITION_STATE_ARRAY_SIZE];
		defense_node_list_array = new PositionLinkedList[Constant.POSITION_STATE_ARRAY_SIZE];
		for(int i=Constant.ALIVE_FOUR;i<Constant.POSITION_STATE_ARRAY_SIZE;i++) {
			attack_node_list_array[i] = new PositionLinkedList(len);
			defense_node_list_array[i] = new PositionLinkedList(len);
		}
		
		positionState_array = new PositionState[Constant.CHESSCNT-1]; //14<<4+14=238
		for(int i=0;i<Constant.CHESSCNT-1;i++)
			positionState_array[i] = new PositionState();
			
	}
	
	//清空
	public void restart() {
		for(int i=0;i<Constant.CHESSCNT-1;i++)
			positionState_array[i].clear();
			
		for(int type=2;type<7;type++) {
			attack_node_list_array[type].reset(Constant.POSITION_LINKED_LIST_MAX_SIZE);
			defense_node_list_array[type].reset(Constant.POSITION_LINKED_LIST_MAX_SIZE);
		}
	}
	
	public void copy(PositionStateMap srcObj) {		
		for(int i=0;i<Constant.CHESSCNT-1;i++)
			positionState_array[i].clear();
			
		for(int type=2;type<7;type++) {
			attack_node_list_array[type].reset(Constant.POSITION_LINKED_LIST_MAX_SIZE);			
			LinkNode src_head = srcObj.attack_node_list_array[type].head;
			while(src_head!=null) {
				int index = src_head.position;
				if(positionState_array[index].can_add_attack(type)) {
					LinkNode linknode = attack_node_list_array[type].add(index);
					positionState_array[index].attack(type, linknode);
				}
				src_head = src_head.next;
			}
			
			defense_node_list_array[type].reset(Constant.POSITION_LINKED_LIST_MAX_SIZE);			
			src_head = srcObj.defense_node_list_array[type].head;
			while(src_head!=null) {
				int index = src_head.position;
				if(positionState_array[index].can_add_defense(type)) {
					LinkNode linknode = defense_node_list_array[type].add(index);
					positionState_array[index].defense(type, linknode);
				}
				src_head = src_head.next;
			}			
		}
	}
	
	public void put() {
		IntArray form_list = Constant.formList;
		IntArray stop_list = Constant.stopList;
		
		for(int i=0;i<form_list.getSize();i++) {
			int position = form_list.get(i);
			if (positionState_array[position].can_add_attack()) {
				LinkNode linknode = attack_node_list_array[StateCalculator.renjuType].add(position);
				positionState_array[position].attack(linknode);
			}
		}
		for(int i=0;i<stop_list.getSize();i++) {
			int position = stop_list.get(i);
			if (positionState_array[position].can_add_defense()) {
				LinkNode linknode = defense_node_list_array[StateCalculator.renjuType].add(position);
				positionState_array[position].defense(linknode);
			}
		}
	}
	
	public void del() {
		IntArray form_list = Constant.formList;
		IntArray stop_list = Constant.stopList;
		
		for(int i=0;i<form_list.getSize();i++) {
			int position = form_list.get(i);
			LinkNode linknode = positionState_array[position].popAttackNode();
			if(linknode != null)
				attack_node_list_array[StateCalculator.renjuType].del(linknode);
		}
		for(int i=0;i<stop_list.getSize();i++) {
			int position = stop_list.get(i);
			LinkNode linknode = positionState_array[position].popDefenseNode();
			if(linknode != null) 
				defense_node_list_array[StateCalculator.renjuType].del(linknode);
		}
	}
	
	public void getAllForm(int type) {
		PositionLinkedList linklist = this.attack_node_list_array[type];
		if(linklist.size>0) {
			linklist.getAll();
		}
	}
	
	public void getAllStop(int type) {
		PositionLinkedList linklist = this.defense_node_list_array[type];
		if(linklist.size>0) {
			linklist.getAll();
		}
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		PositionLinkedList alist = attack_node_list_array[2];
		sb.append("活四进攻 ").append(alist.debugInfo()).append("\r\n");
		alist = attack_node_list_array[3];
		sb.append("眠四进攻 ").append(alist.debugInfo()).append("\r\n");
		alist = attack_node_list_array[4];
		sb.append("活三进攻 ").append(alist.debugInfo()).append("\r\n");
		alist = attack_node_list_array[5];
		sb.append("眠三进攻 ").append(alist.debugInfo()).append("\r\n");
		alist = attack_node_list_array[6];
		sb.append("活二进攻 ").append(alist.debugInfo()).append("\r\n");
		
		alist = defense_node_list_array[2];
		sb.append("活四防守 ").append(alist.debugInfo()).append("\r\n");
		alist = defense_node_list_array[3];
		sb.append("眠四防守 ").append(alist.debugInfo()).append("\r\n");
		alist = defense_node_list_array[4];
		sb.append("活三防守 ").append(alist.debugInfo()).append("\r\n");
		alist = defense_node_list_array[5];
		sb.append("眠三防守 ").append(alist.debugInfo()).append("\r\n");
		alist = defense_node_list_array[6];
		sb.append("活二防守 ").append(alist.debugInfo()).append("\r\n");
		return sb.toString();
		
	}
	
	
}
