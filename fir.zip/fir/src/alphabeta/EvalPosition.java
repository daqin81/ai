package alphabeta;

public class EvalPosition {

	public int index; //点的索引
 	
	public int weight;
	
	public EvalPosition(int index, int weight) {
		this.index = index;
		this.weight = weight;
	}
	
}
