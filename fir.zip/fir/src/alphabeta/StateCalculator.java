package alphabeta;

import common.Constant;

public class StateCalculator {

	public int start_point;
	
	public int type;
	
	public int left_blank_cnt;
	
	public int right_blank_cnt;
	
	public int continue_blank_cnt;  //连续两个空格就切换
	
	public int middle_blank_cnt; //中间出现空格的情况
	public int middle_blank_index; //中间空格出现的位置
	
	public int total_cnt;
	
	public int state;  //0:initial, 1:black, 2:white, 3:blank
	
	public int end_point;
	
	public int[][] chessCnt; //总状态
	
	public int[] delta = {1, 16, 17, -15}; //四个方向上相邻的点的坐标差
	
	///////////////////////////
	public PositionStateMap[] positionStateMap_array;  //采用数组减少分支判断
	
	///////////////////////////
	
	public GobangBoard gobangBoard;
	
	///////////////////////////
	//store tmp parameter 减少栈的开销
	int[] in_array;
	public static int startIndex, direction, length;
	public static boolean addFlag, vcfFlag;
	int cur_index;
	int blank_cnt;
	public static int renjuType;
	int start_state;
	
	public StateCalculator(GobangBoard gobangBoard) {
		this.gobangBoard = gobangBoard;
		this.in_array = GobangBoard.sb.getValue();
		chessCnt = new int[3][Constant.MAX_CHESS_TYPE];
		positionStateMap_array = new PositionStateMap[3]; //0未用上
		for(int i=1;i<3;i++)
			positionStateMap_array[i] = new PositionStateMap();
	}
	
	public void copy(StateCalculator srcObj) {
		int[][] src_chessCnt = srcObj.chessCnt;
		for(int i=0;i<3;i++)
			for(int j=0;j<Constant.MAX_CHESS_TYPE;j++)
				chessCnt[i][j] = src_chessCnt[i][j];
		for(int i=1;i<3;i++)
			positionStateMap_array[i].copy(srcObj.positionStateMap_array[i]);
		
	}
	
	public void getFormPoint(int pointType, int type) {
		positionStateMap_array[pointType].getAllForm(type);
	}
	
	public void getStopPoint(int pointType, int type) {
		positionStateMap_array[pointType].getAllStop(type);
	}
	
	//切换, black,white状态切换
	public void switchState() {
		if(in_array[cur_index-1]==Constant.NONE) {
			this.end_point = cur_index-2;
			right_blank_cnt = 1;
		}
		else {
			this.end_point = cur_index-1;
			right_blank_cnt = 0;
		}
		total_cnt = end_point - start_point + 1 - middle_blank_cnt;
		//计算left
		calcLeft();
		calcType();
	}
	
	//开始状态,当initial或blank遇到black或white
	public void startState() {
		this.state = start_state;
		this.start_point = cur_index;
		continue_blank_cnt = 0;
		middle_blank_cnt = 0;
	}
	
	//计算left
	public void calcLeft() {		
		if(start_point>0&&in_array[start_point-1]==Constant.NONE) {
			left_blank_cnt = 1;
			if(start_point>1&&in_array[start_point-2]==Constant.NONE) {
				left_blank_cnt = 2;
				//对于2的情况
				if(total_cnt == 2 && start_point>2&&in_array[start_point-3]==Constant.NONE) {
					left_blank_cnt = 3;
				}
			}
		}
		else
			left_blank_cnt = 0;
	}
	
	//结束状态,当black或white遇到连续两个空格(。。。__ )，或者中间出现了一个空格，末尾再出现一个空格时(。_。。_)
	public void endState() {
		this.end_point = cur_index-blank_cnt;
		this.right_blank_cnt = blank_cnt;
		total_cnt = end_point - start_point + 1 - middle_blank_cnt;		
		//对于2的情况
		if(total_cnt == 2) {
			if(end_point+2<length&&right_blank_cnt == 1&&in_array[end_point+2]==Constant.NONE)
				right_blank_cnt = 2;
			if(right_blank_cnt == 2 && end_point+3<length&&in_array[end_point+3]==Constant.NONE) {
				right_blank_cnt = 3;
			}
		}
		//计算left
		calcLeft();
		calcType();
	}
	
	//只需把状态复位
	public void reset() {		
		state = Constant.STATE_INITIAL;  //0:initial, 1:black, 2:white, 3:blank
	}
	
	public void getKeyPoint() {
		
		try {
		Constant.formList.reset();
		Constant.stopList.reset();
		
		int index;
		switch(renjuType) {
		//alive four
		case Constant.ALIVE_FOUR:	
			index = startIndex + (start_point - 1)*delta[direction];
			Constant.formList.append(index);
			Constant.stopList.append(index);
			break;
		
		//sleep four
		case Constant.SLEEP_FOUR:
			if(middle_blank_cnt>0) {
				index = startIndex + middle_blank_index*delta[direction];
			}
			else if(left_blank_cnt>0) {
				index = startIndex + (start_point - 1)*delta[direction];
			}
			else {
				index = startIndex + (end_point + 1)*delta[direction];
			}
			Constant.formList.append(index);
			Constant.stopList.append(index);
			break;
	    
		//alive three	
		case Constant.ALIVE_THREE:
			if(middle_blank_cnt>0) {
				index = startIndex + middle_blank_index*delta[direction];
				Constant.formList.append(index);
				Constant.stopList.append(index);
				
				index = startIndex + (start_point - 1)*delta[direction];
				Constant.stopList.append(index);
				index = startIndex + (end_point + 1)*delta[direction];
				Constant.stopList.append(index);
			}
			else if(left_blank_cnt>1 && right_blank_cnt>1) {
				index = startIndex + (start_point - 1)*delta[direction];
				Constant.formList.append(index);
				Constant.stopList.append(index);
				
				index = startIndex + (end_point + 1)*delta[direction];
				Constant.formList.append(index);
				Constant.stopList.append(index);
			}
			else if(left_blank_cnt==1) {
				index = startIndex + (end_point + 1)*delta[direction];
				Constant.formList.append(index);
				Constant.stopList.append(index);
				
				index = startIndex + (start_point - 1)*delta[direction];
				Constant.stopList.append(index);
				index = startIndex + (end_point + 2)*delta[direction];
				Constant.stopList.append(index);
			}
			else {
				index = startIndex + (start_point - 1)*delta[direction];
				Constant.formList.append(index);
				Constant.stopList.append(index);
				
				index = startIndex + (start_point - 2)*delta[direction];
				Constant.stopList.append(index);
				index = startIndex + (end_point + 1)*delta[direction];
				Constant.stopList.append(index);
			}	
			break;
		
		//sleep three
		case Constant.SLEEP_THREE:
			if(middle_blank_cnt>0) {
				index = startIndex + middle_blank_index*delta[direction];
				Constant.formList.append(index);
				Constant.stopList.append(index);				
			}
			if(left_blank_cnt>0) {
				index = startIndex + (start_point - 1)*delta[direction];
				Constant.formList.append(index);
				Constant.stopList.append(index);

				if(middle_blank_cnt==0 && left_blank_cnt>1) {
					index = startIndex + (start_point - 2)*delta[direction];
					Constant.formList.append(index);
					Constant.stopList.append(index);
				}
			}
			else {
				index = startIndex + (end_point + 1)*delta[direction];
				Constant.formList.append(index);
				Constant.stopList.append(index);
				
				if(middle_blank_cnt==0 && right_blank_cnt>1) {
					index = startIndex + (end_point + 2)*delta[direction];
					Constant.formList.append(index);
					Constant.stopList.append(index);					
				}
			}
			break;
	    
		//alive two	
		case Constant.ALIVE_TWO:
			if(middle_blank_cnt>0) {
				index = startIndex + middle_blank_index*delta[direction];
				Constant.formList.append(index);
				Constant.stopList.append(index);
				if(left_blank_cnt>1) {
					index = startIndex + (start_point - 1)*delta[direction];
					Constant.formList.append(index);
					Constant.stopList.append(index);
				}
				if(right_blank_cnt>1) {
					index = startIndex + (end_point + 1)*delta[direction];
					Constant.formList.append(index);
					Constant.stopList.append(index);
				}
				
				int maxLeft = 3-right_blank_cnt>left_blank_cnt?left_blank_cnt:3-right_blank_cnt;
				for(int i=2;i<=maxLeft;i++) {
					index = startIndex + (start_point - i)*delta[direction];
					Constant.stopList.append(index);
				}
				
				int maxRight = 3-left_blank_cnt>right_blank_cnt?right_blank_cnt:3-left_blank_cnt;
				for(int i=2;i<=maxRight;i++) {
					index = startIndex + (end_point + i)*delta[direction];
					Constant.stopList.append(index);
				}
			}
			else {
				if(left_blank_cnt>1) {
					index = startIndex + (start_point - 1)*delta[direction];
					Constant.formList.append(index);
				}
				if(left_blank_cnt>2) {
					index = startIndex + (start_point - 2)*delta[direction];
					Constant.formList.append(index);
				}						
				if(right_blank_cnt>1) {
					index = startIndex + (end_point + 1)*delta[direction];
					Constant.formList.append(index);
				}
				if(right_blank_cnt>2) {
					index = startIndex + (end_point + 2)*delta[direction];
					Constant.formList.append(index);
				}

				int maxLeft = 4-right_blank_cnt>left_blank_cnt?left_blank_cnt:4-right_blank_cnt;
				for(int i=1;i<=maxLeft;i++) {
					index = startIndex + (start_point - i)*delta[direction];
					Constant.stopList.append(index);
				}
				
				int maxRight = 4-left_blank_cnt>right_blank_cnt?right_blank_cnt:4-left_blank_cnt;
				for(int i=1;i<=maxRight;i++) {
					index = startIndex + (end_point + i)*delta[direction];
					Constant.stopList.append(index);
				}
			}
			break;
		  }//end of switch
		}catch(Exception ex) {
			ex.printStackTrace();
			System.out.println("overflow");
			throw ex;
		}
	}
	
	//计算识别类型并赋值给type
	public void calcType() {
		try {
		if(total_cnt == 5) {
			type = Constant.FIVE;
			if(addFlag)
				chessCnt[state][Constant.FIVE]++;
			else
				chessCnt[state][Constant.FIVE]--;
		}
		else if(total_cnt == 4) {
			if(left_blank_cnt>0 && right_blank_cnt>0 && middle_blank_cnt==0) {
				type = Constant.ALIVE_FOUR;
				if(addFlag) {
					chessCnt[state][Constant.ALIVE_FOUR]++;
					if(vcfFlag) {
						renjuType = Constant.ALIVE_FOUR;
						getKeyPoint();
						positionStateMap_array[state].put();
					}
				}
				else {
					chessCnt[state][Constant.ALIVE_FOUR]--;
					if(vcfFlag) {
						renjuType = Constant.ALIVE_FOUR;
						getKeyPoint();
						positionStateMap_array[state].del();
					}
				}
			}
			else if(left_blank_cnt>0 || right_blank_cnt>0 || middle_blank_cnt>0) {
				type = Constant.SLEEP_FOUR;
				if(addFlag) {
					chessCnt[state][Constant.SLEEP_FOUR]++;
					if(vcfFlag) {
						renjuType = Constant.SLEEP_FOUR;
						getKeyPoint();
						positionStateMap_array[state].put();
					}
				}
				else {
					chessCnt[state][Constant.SLEEP_FOUR]--;
					if(vcfFlag) {
						renjuType = Constant.SLEEP_FOUR;
						getKeyPoint();
						positionStateMap_array[state].del();
					}
				}
			}
			else
				type = Constant.BLOCK;
		}
		
		else if(total_cnt == 3) {
			if(left_blank_cnt>0 && right_blank_cnt>0 && left_blank_cnt + right_blank_cnt + middle_blank_cnt > 2) {
				type = Constant.ALIVE_THREE;
				if(addFlag) {
					chessCnt[state][Constant.ALIVE_THREE]++;
					if(vcfFlag) {
						renjuType = Constant.ALIVE_THREE;
						getKeyPoint();
						positionStateMap_array[state].put();
					}
				}
				else {
					chessCnt[state][Constant.ALIVE_THREE]--;
					if(vcfFlag) {
						renjuType = Constant.ALIVE_THREE;
						getKeyPoint();
						positionStateMap_array[state].del();
					}
				}
			}
			else if(left_blank_cnt + right_blank_cnt + middle_blank_cnt>1) {
				type = Constant.SLEEP_THREE;
				if(addFlag) {
					chessCnt[state][Constant.SLEEP_THREE]++;
					if(vcfFlag) {
						renjuType = Constant.SLEEP_THREE;
						getKeyPoint();
						positionStateMap_array[state].put();
					}
				}
				else {
					chessCnt[state][Constant.SLEEP_THREE]--;
					if(vcfFlag) {
						renjuType = Constant.SLEEP_THREE;
						getKeyPoint();
						positionStateMap_array[state].del();
					}
				}
			}
			else
				type = Constant.BLOCK;
		}
		
		else if(total_cnt == 2) {
			if(left_blank_cnt>0 && right_blank_cnt>0 && left_blank_cnt + right_blank_cnt + middle_blank_cnt > 3) {
				type = Constant.ALIVE_TWO;
				if(addFlag) {
					chessCnt[state][Constant.ALIVE_TWO]++;
					if(vcfFlag) {
						renjuType = Constant.ALIVE_TWO;
						getKeyPoint();
						positionStateMap_array[state].put();
					}
				}
				else {
					chessCnt[state][Constant.ALIVE_TWO]--;
					if(vcfFlag) {
						renjuType = Constant.ALIVE_TWO;
						getKeyPoint();
						positionStateMap_array[state].del();
					}
				}
			}
			else if(left_blank_cnt + right_blank_cnt + middle_blank_cnt>2) {
				type = Constant.SLEEP_TWO;
				if(addFlag)
					chessCnt[state][Constant.SLEEP_TWO]++;
				else
					chessCnt[state][Constant.SLEEP_TWO]--;
			}
			else
				type = Constant.BLOCK;
		}
		
		else if(total_cnt == 1) {
			if(left_blank_cnt>0 && right_blank_cnt>0) {
				type = Constant.ALIVE_ONE;
				if(addFlag)
					chessCnt[state][Constant.ALIVE_ONE]++;
				else
					chessCnt[state][Constant.ALIVE_ONE]--;
			}
			else if(left_blank_cnt>0 || right_blank_cnt>0 || middle_blank_cnt>0) {
				type = Constant.SLEEP_ONE;
			}
			else
				type = Constant.BLOCK;
		}
		}catch(Exception ex) {			
			ex.printStackTrace();
		}
	}
	
	public void evaluate() {
		reset();	
		int i;
		for ( i = 0; i < length; i++) {
			int input = in_array[i];
			switch (state) {

			case Constant.STATE_INITIAL:
				if(input == Constant.WHITE) {
					cur_index = i;
					start_state = Constant.STATE_WHITE;
					startState();//开始状态
				}
				else if(input == Constant.BLACK) {
					cur_index = i;
					start_state = Constant.STATE_BLACK;
					startState();//开始状态
				}
				else if(input == Constant.NONE) {
					state = Constant.STATE_EMPTY;//开始状态
				}
				break;

			case Constant.STATE_BLACK:
			case Constant.STATE_WHITE:
				if(input == Constant.NONE) {
					continue_blank_cnt++;
					//如果中间空格没有出现,continue_blank_cnt等于2
					//如果出现中间空格,continue_blank_cnt等于1,middle_blank_cnt等于1
					if(continue_blank_cnt+middle_blank_cnt>1) {
						//记录并切换状态
						cur_index = i;
						blank_cnt = continue_blank_cnt;
						endState();
						//切换状态
						state = Constant.STATE_EMPTY;
					}					
				}				
				else if(input == state) {
					//继续
					if(continue_blank_cnt == 1) {
						continue_blank_cnt = 0; //不连续，重新开始计数
						middle_blank_cnt = 1;
						middle_blank_index = i-1; //中间出现空格的时候赋值即可
					}
					//检查长连的情况,避免把两个串中间的单个连接当做中间空格形成一个长连
					if(middle_blank_cnt == 1 && i-start_point>4) {
						i = middle_blank_index;//回退
						middle_blank_cnt = 0;
						//记录
						cur_index = i;
						blank_cnt = 1;
						endState();
						//切换状态
						state = Constant.STATE_EMPTY;
					}
				}				
				else /* if(delta != state) */ {
					//记录
					cur_index = i;
					switchState();
					//切换状态
					start_state = input;
					startState();
				}
				
				break;

			case Constant.STATE_EMPTY:
				if(input == Constant.WHITE) {
					cur_index = i;
					start_state = Constant.STATE_WHITE;
					startState(); //开始状态
				}
				else if(input == Constant.BLACK) {
					cur_index = i;
					start_state = Constant.STATE_BLACK;
					startState(); //开始状态
				}
				break;

			default:
				break;

			}
		}
		
		//末尾处理
		switch (state) {
			case Constant.STATE_BLACK:
			case Constant.STATE_WHITE:
				//记录
				cur_index = i;
				switchState();
				reset();//结束状态
				break;
	
			case Constant.STATE_EMPTY:
				//无记录
				reset();//结束状态
				break;
	
			default:
				break;
		}
	}
	
	public void restart(){
		for(int i=1;i<3;i++)
			for(int j=1;j<9;j++) {
				chessCnt[i][j] = 0;
			}
		for(int i=1;i<3;i++)
			positionStateMap_array[i].restart();
	}
	
	@Override
	public String toString(){
		StringBuffer sb = new StringBuffer();
		sb.append("黑 活四 : " + chessCnt[1][Constant.ALIVE_FOUR]+"  ");
		sb.append("黑 眠四 : " + chessCnt[1][Constant.SLEEP_FOUR]+"  ");
		sb.append("黑 活三 : " + chessCnt[1][Constant.ALIVE_THREE]+"    ");
		sb.append("黑 眠三 : " + chessCnt[1][Constant.SLEEP_THREE]+"    ");
		sb.append("黑 活二 : " + chessCnt[1][Constant.ALIVE_TWO]+"  -----  ");
		sb.append("白 活四 : " + chessCnt[2][Constant.ALIVE_FOUR]+"  ");
		sb.append("白 眠四 : " + chessCnt[2][Constant.SLEEP_FOUR]+"  ");
		sb.append("白 活三 : " + chessCnt[2][Constant.ALIVE_THREE]+"  ");
		sb.append("白 眠三 : " + chessCnt[2][Constant.SLEEP_THREE]+"  ");
		sb.append("白 活二 : " + chessCnt[2][Constant.ALIVE_TWO]+"  ");
		return sb.toString();
	}
	
}
