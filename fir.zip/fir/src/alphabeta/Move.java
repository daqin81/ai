package alphabeta;

import common.Util;

public class Move {

	public int row;
	
	public int column;
	
	public int index;
	
	public int type;
	
	public Move(int row, int column, int type){
		this.row = row;
		this.column = column;
		this.type = type;
		index = Util.getIndex(row, column);
	}
	
	//其他数据初始化时固定了
	public void copy(Move srcObj) {
		this.type = srcObj.type; 
	}
	
}
