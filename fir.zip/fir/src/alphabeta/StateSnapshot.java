package alphabeta;

import common.Constant;

//比较下棋前后变化,可用于禁手判断
public class StateSnapshot {

	public int[][] chess_cnt;
		
	public StateSnapshot() {
		chess_cnt = new int[3][Constant.MAX_CHESS_TYPE];
	}
	
	public void clear() {
		for(int i=1;i<3;i++)
			for(int j=1;j<9;j++) {
				chess_cnt[i][j] = 0;
			}
	}
	
	public void copy(StateCalculator stateCalculator) {
		for(int i=1;i<3;i++)
			for(int j=1;j<9;j++) {
				chess_cnt[i][j] = stateCalculator.chessCnt[i][j];
			}
	}
	
	//求差值
	public void diff(StateCalculator stateCalculator) {
		for(int i=1;i<3;i++)
			for(int j=1;j<9;j++) {
				chess_cnt[i][j] = stateCalculator.chessCnt[i][j]-chess_cnt[i][j];
			}	
	}
	
	public boolean forbiddenCheck() {
		
		//未考虑长连 //TODO
		
		if(chess_cnt[1][Constant.FIVE]>0)
			return false;
		if(chess_cnt[1][Constant.ALIVE_FOUR] + chess_cnt[1][Constant.SLEEP_FOUR]>1) {
			return true;
		}
		if(chess_cnt[1][Constant.ALIVE_THREE]>1) {
			return true;
		}
		return false;		
	}
	
}
