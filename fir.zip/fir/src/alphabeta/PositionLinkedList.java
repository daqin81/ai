package alphabeta;

import common.Constant;
import common.Util;

public class PositionLinkedList {

	public LinkNode head;

	public LinkNode tail;
	
	public int size;
	
	public LinkNode[] element;
	
	//指示数据存到数组哪个位置
	public IndexStack indexStack;
	
	public PositionLinkedList(int len) {
		this.head = null;
		this.tail = null;
		init(len);
	}
	
	public void init(int len) {
		element = new LinkNode[len];
		indexStack = new IndexStack(len);
		for(int i=0;i<len;i++) {
			LinkNode node = new LinkNode(i);//每个元素都有固定的id
			element[i] = node;
		}
		for(int i=len-1;i>=0;i--) {
			indexStack.push(i);
		}
	}
	
	//重置
	public void reset(int len) {
		this.head = null;
		this.tail = null;
		size = 0;
		indexStack.clear();
		for(int i=len-1;i>=0;i--) {
			indexStack.push(i);
		}
	}
	
	public LinkNode add(int position) {
		LinkNode linkNode;
		int index = indexStack.pop();
		linkNode = element[index];
		linkNode.position = position;
		linkNode.next = null;
		
		if(this.tail == null) {
			linkNode.prev = null;
			this.head = linkNode;
			this.tail = linkNode;
		}
		else {			
			linkNode.prev = this.tail;
			this.tail.next = linkNode;
			this.tail = linkNode;
		}
		size++;
		return linkNode;
	}
	
	public void del(LinkNode linkNode) {
		LinkNode prev = linkNode.prev;
		LinkNode next = linkNode.next;
		if(prev != null && next != null) {
			prev.next = next;
			next.prev = prev;
			linkNode.prev = null;
			linkNode.next = null;
		}
		else if(prev != null ) {
			prev.next = null;
			linkNode.prev = null;
			this.tail = prev;
		}
		else if(next != null) {
			next.prev = null;
			linkNode.next = null;
			this.head = next;
		}
		else {
			this.head = null;
			this.tail = null;
		}
		size--;
		this.indexStack.push(linkNode.index);
	}
	
	public void getAll() {
		Constant.ret_Points.reset();
		LinkNode tmp = this.head;
		while(tmp!=null) {
			Constant.ret_Points.append(tmp.position);
			tmp = tmp.next;
		}
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("PositionLinkedList [size=" + size + ", element=");
		LinkNode tmp = this.head;
		boolean flag = false;
		while(tmp!=null) {
			String prevStr = tmp.prev==null?"null":tmp.prev.index+"";
			String nextStr = tmp.next==null?"null":tmp.next.index+"";
			sb.append(tmp.position).append(" index:").append(tmp.index)
			.append(" prev:"+prevStr).append(" next:"+nextStr).append(";");
			LinkNode tmpprev = tmp;
			tmp = tmp.next;
			if(tmp == null) {
				if(tmpprev.index != tail.index) {
					flag = true;
				}
			}
		}
		sb.append(" head=" + head + ", tail=" + tail);
		sb.append(", indexStack=" + indexStack + "]");
		if(flag)
			sb.append("\r\ntail error");
		return sb.toString();
	}
	
	public String debugInfo() {
		StringBuffer sb = new StringBuffer();
		sb.append("size=" + size + ", element=");
		LinkNode tmp = this.head;
		while(tmp!=null) {
			int row = Util.getRow(tmp.position);
			int col = Util.getCol(tmp.position);
			sb.append("row:" + row + " col:" + col).append(" ");
			tmp = tmp.next;
		}
		return sb.toString();
	}
	
}
