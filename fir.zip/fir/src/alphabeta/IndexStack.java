package alphabeta;

public class IndexStack {

	public int[] elementData;
	
	public int elementCount;
	
	public IndexStack(int size) {
		this.elementData = new int[size];
	}
	
	public void push(int item) {
		elementData[elementCount++] = item;
    }
	
	public int pop() {
	        int obj = elementData[elementCount - 1];
	        elementCount--;
	        return obj;
    }
	
	 public void clear() {
		 elementCount = 0;
	 }
	 
	@Override
	public String toString(){
		StringBuffer sb = new StringBuffer();
		for(int i=elementCount-1;i>=0;i--) {
			sb.append(elementData[i]).append(" ");
		}
		return sb.toString();
	}
	 
}
