package alphabeta;

//用于board里的一行(四个方向之一)或者计算得到的关键点(胜点、堵点)
public class IntArray {
	
	private int value[];
	
	private int count;

	public IntArray(int size){
		value = new int[size];
		count = 0;
	}
	
	public void append(int c) {
        value[count++] = c;
    }
		
	public int[] getValue() {
		return value;
	}
		
	public void reset(){
		count = 0;
	}
	
	public int getSize() {
		return count;
	}
	
	public int get(int i) {
		return value[i];
	}
	
	public void copy(IntArray list) {
		count = 0;
		for(int i=0;i<list.count;i++)
			value[count++] = list.value[i];
	}
	
	public void add(IntArray list) {
		for(int i=0;i<list.count;i++)
			value[count++] = list.value[i];
	}
	
}
