package alphabeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import aotree.AOTree;
import common.Constant;
import common.Util;

public class GobangBoard {
	
	public Move[] move_board;  //生成常量数组,引用即可,不必每次new
	
	private Stack<Move> move_stack;
	
	public static IntArray sb = new IntArray(Constant.DIMENSION);

	//TODO  评估时要正反两个方向分别计数，哪个方向有优势，采用哪个方向的评估方法
	private StateCalculator stateCalc = new StateCalculator(this);  //新的数棋方式
	
	private int[] horizonStartPoint;
	private int[] verticalStartPoint; 
	private int[] leftUpStartPoint; //点的左上对角顶端
	private int[] leftDownStartPoint; //点的左下对角顶端
	
	private int[] horizonEndPoint;
	private int[] verticalEndPoint; 
	private int[] leftUpEndPoint; //点的右下对角顶端
	private int[] leftDownEndPoint; //点的右上对角顶端
		
	private IntArray tmp_Points = new IntArray(30);  //暂存，多次用ret_Points存结果时防止覆盖用tmp_Points暂存
	
	private AOTree aoTree = new AOTree(this);  //vcf
	
	private StateSnapshot stateSnapshot = new StateSnapshot(); //
	
	public static int chessIndex;
	
	public static int nextChessType; //将要下的
	
	public static int selfType;  //本方
	
	public GobangBoard(){
		move_board = new Move[Constant.CHESSCNT];
	    
	    for (int i = 0; i < Constant.DIMENSION; i++) {
	    	for (int j = 0; j < Constant.DIMENSION+1; j++) {
	    		int index = Util.getIndex(i, j);
	    		this.move_board[index] = new Move(i,j,j<15?Constant.NONE:Constant.OUTRANGE);
	    	}
	    }
	    
	    this.move_stack = new Stack<Move>();
	    
	    initParam(); //初始化一些参数值
	    
	}
	
	//copy
	public void copy(GobangBoard srcObj){
		this.move_stack.clear();
		Stack<Move> src_move_stack = srcObj.move_stack;
		for(int i=0;i<src_move_stack.size();i++) {
			this.move_stack.add(src_move_stack.get(i));
		}
		Move[] src_move_board = srcObj.move_board;
		for(int i=0;i<src_move_board.length;i++)
			move_board[i].copy(src_move_board[i]);
		
		StateCalculator src_stateCalc = srcObj.stateCalc;
		stateCalc.copy(src_stateCalc);
		
	}
	
	public void initParam() {
		horizonStartPoint = new int[Constant.CHESSCNT];
		verticalStartPoint = new int[Constant.CHESSCNT];
		leftUpStartPoint = new int[Constant.CHESSCNT];
		leftDownStartPoint = new int[Constant.CHESSCNT];
		
		horizonEndPoint = new int[Constant.CHESSCNT];
		verticalEndPoint = new int[Constant.CHESSCNT];
		leftUpEndPoint = new int[Constant.CHESSCNT];
		leftDownEndPoint = new int[Constant.CHESSCNT];
		
		for (int row = 0; row < Constant.DIMENSION; row++) {
	        for (int col = 0; col < Constant.DIMENSION; col++) {
	        	int rowStart, colStart;
	        	int rowEnd, colEnd;
	        	int index = Util.getIndex(row,col);
	        	//horizon
	        	rowStart = row;
	        	colStart = 0;
	        	rowEnd = row;
	        	colEnd = 14;
	        	horizonStartPoint[index] = Util.getIndex(rowStart,colStart);
	        	horizonEndPoint[index] = Util.getIndex(rowEnd,colEnd);
	        	
	        	//vertical
	        	rowStart = 0;
	        	colStart = col;
	        	rowEnd = 14;
	        	colEnd = col;
	        	verticalStartPoint[index] = Util.getIndex(rowStart,colStart);
	        	verticalEndPoint[index] = Util.getIndex(rowEnd,colEnd);
	        	
	        	//left up
	        	int delta = row - col;	    		
	    	    if(delta<0) {
	    	    	rowStart = 0;
	    	    	colStart = -delta;
	    	    	rowEnd = 14+delta;
	    	    	colEnd = 14;
	    	    }
	    	    else {
	    	    	rowStart = delta;
	    	    	colStart = 0;
	    	    	rowEnd = 14;
	    	    	colEnd = 14-delta;
	    	    }
	    	    leftUpStartPoint[index] = Util.getIndex(rowStart, colStart);
	    	    leftUpEndPoint[index] = Util.getIndex(rowEnd, colEnd);
	    	    
	    	    //right up
	    		//起点,左下
	    	    int sum = row+col;
	    	    if(sum<15) {
	    	    	rowStart = sum;
	    	    	colStart = 0;
	    	    }
	    	    else {
	    	    	rowStart = 14;
	    	    	colStart = sum-14;
	    	    }
	    		rowEnd = colStart;
	    		colEnd = rowStart;
	    		leftDownStartPoint[index] = Util.getIndex(rowStart, colStart);
	    		leftDownEndPoint[index] = Util.getIndex(rowEnd, colEnd);
	        }
		}
		
	}
	
	
	@Override
	public String toString(){
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < Constant.DIMENSION; i++) {
			if (i == 0) {
				sb.append(
						(i < 10 ? "0" + i : i) + (this.move_board[Util.getIndex(i,0)].type == Constant.NONE ? "┌ " : this.move_board[Util.getIndex(i,0)].type == Constant.WHITE ? "○ " : "● "));
			} else if (i == Constant.DIMENSION - 1) {
				sb.append(
						(i < 10 ? "0" + i : i) + (this.move_board[Util.getIndex(i,0)].type == Constant.NONE ? "└ " : this.move_board[Util.getIndex(i,0)].type == Constant.WHITE ? "○ " : "● "));
			} else {
				sb.append(
						(i < 10 ? "0" + i : i) + (this.move_board[Util.getIndex(i,0)].type == Constant.NONE ? "├ " : this.move_board[Util.getIndex(i,0)].type == Constant.WHITE ? "○ " : "● "));
			}
			for (int j = 1; j < Constant.DIMENSION - 1; j++) {
				if (i == 0) {
					sb.append(this.move_board[Util.getIndex(i,j)].type == Constant.NONE ? " ┬ " : this.move_board[Util.getIndex(i,j)].type == Constant.WHITE ? " ○ " : " ● ");
				} else if (i == Constant.DIMENSION - 1) {
					sb.append(this.move_board[Util.getIndex(i,j)].type == Constant.NONE ? " ┴ " : this.move_board[Util.getIndex(i,j)].type == Constant.WHITE ? " ○ " : " ● ");
				} else {
					sb.append(this.move_board[Util.getIndex(i,j)].type == Constant.NONE ? " ┼ " : this.move_board[Util.getIndex(i,j)].type == Constant.WHITE ? " ○ " : " ● ");
				}
			}
			if (i == 0) {
				sb.append(this.move_board[Util.getIndex(i,Constant.DIMENSION - 1)].type == Constant.NONE ? " ┐\r\n"
						: this.move_board[Util.getIndex(i,Constant.DIMENSION - 1)].type == Constant.WHITE ? "○\r\n" : "●\r\n");
			} else if (i == Constant.DIMENSION - 1) {
				sb.append(this.move_board[Util.getIndex(i,Constant.DIMENSION - 1)].type == Constant.NONE ? " ┘\r\n"
						: this.move_board[Util.getIndex(i,Constant.DIMENSION - 1)].type == Constant.WHITE ? "○\r\n" : "●\r\n");
			} else {
				sb.append(this.move_board[Util.getIndex(i,Constant.DIMENSION - 1)].type == Constant.NONE ? " ┤\r\n"
						: this.move_board[Util.getIndex(i,Constant.DIMENSION - 1)].type == Constant.WHITE ? "○\r\n" : "●\r\n");
			}
		}
		return sb.toString();
	}
	
	public Move current(){
	    int l = this.move_stack.size();
	    if (l>0) {
	        return this.move_stack.peek();
	    }
	    return null;
	}
	
	public void put() {
	    if (this.move_board[chessIndex].type == Constant.NONE) {
	    	//TODO,先存个快照
	    	this.stateSnapshot.copy(this.stateCalc);
	    	
	    	StateCalculator.addFlag = false;	    	
			calcState();
	    	
	        this.move_board[chessIndex].type = GobangBoard.nextChessType;
	        StateCalculator.addFlag = true;
			calcState();
	        //TODO, 求出步骤产生的改变项
	        this.stateSnapshot.diff(this.stateCalc);  
	        
	        //放进记录堆栈
	        Move move = move_board[chessIndex];
	        this.move_stack.push(move);
	    }
	    else System.err.println("row:" + move_board[chessIndex].row + "col:" + move_board[chessIndex].column + "type:" + GobangBoard.nextChessType );
	}
	
	public void rollback() {
	    //记录后退的n步走法
    	Move step = this.move_stack.pop();
        if (step != null) {
        	chessIndex = step.index;
            StateCalculator.addFlag = false;
		    calcState();
            
	    	//置空格点
            this.move_board[chessIndex].type = Constant.NONE;
            StateCalculator.addFlag = true;
		    calcState();
	        
        }
	}

	public void restart(){
		this.move_stack.clear();
		for (int i = 0; i < Constant.DIMENSION; i++) {
	        for (int j = 0; j < Constant.DIMENSION; j++) {
	            this.move_board[Util.getIndex(i,j)].type = Constant.NONE;
	        }
	    }
		this.stateCalc.restart();
	}
	
	public boolean inRange(int index) {
		return index>=0 && index<Constant.CHESSCNT;
	}
	
	public boolean isBlank(int index) {
		return this.move_board[index].type == Constant.NONE;
	}
	
	public boolean findChess(int row, int column) {
	    return row >= 0 && row < Constant.DIMENSION && column >= 0 && column < Constant.DIMENSION && this.move_board[Util.getIndex(row,column)].type > Constant.NONE;
	}
	
	public int getMoveCount() {
		return this.move_stack.size();
	}
	
	public Move getMove(int i) {
		return this.move_stack.get(i);
	}
	
	public List<Integer> getNearPoints(Move p) {
		List<Integer> points = new ArrayList<Integer>();
	    
	    int index = p.index;
	    int tmp;
	    //-
	    for(int i=-1;i>-3;i--) {
		    tmp = index+i;
		    if(inRange(tmp)) {
		    	if(isBlank(tmp))
		    		points.add(tmp);		    	
		    }
		    else
		    	break;
	    }
	    for(int i=1;i<3;i++) {
		    tmp = index+i;
		    if(inRange(tmp)) {
		    	if(isBlank(tmp))
		    		points.add(tmp);
		    }
		    else
		    	break;
	    }
	    
	    //|
	    for(int i=-1;i>-3;i--) {
		    tmp = index+(i<<4);
		    if(inRange(tmp)) {
		    	if(isBlank(tmp))
		    		points.add(tmp);
		    }
		    else
		    	break;
	    }
	    for(int i=1;i<3;i++) {
		    tmp = index+(i<<4);
		    if(inRange(tmp)) {
		    	if(isBlank(tmp))
		    		points.add(tmp);
		    }
		    else
		    	break;
	    }
	    
	    ///
	    for(int i=-1;i>-3;i--) {
		    tmp = index+(i<<4)-i;
		    if(inRange(tmp)) {
		    	if(isBlank(tmp))
		    		points.add(tmp);
		    }
		    else
		    	break;
	    }
	    for(int i=1;i<3;i++) {
		    tmp = index+(i<<4)-i;
		    if(inRange(tmp)) {
		    	if(isBlank(tmp))
		    		points.add(tmp);
		    }
		    else
		    	break;
	    }
	    
	    //\
	    for(int i=-1;i>-3;i--) {
		    tmp = index+(i<<4)+i;
		    if(inRange(tmp)) {
		    	if(isBlank(tmp))
		    		points.add(tmp);
		    }
		    else
		    	break;
	    }
	    for(int i=1;i<3;i++) {
		    tmp = index+(i<<4)+i;
		    if(inRange(tmp)) {
		    	if(isBlank(tmp))
		    		points.add(tmp);
		    }
		    else
		    	break;
	    }
	    
	    return points;
	}
	
	public List<Integer> availableSteps() {
		List<Integer> availableSteps = new ArrayList<Integer>();
	    int row = Constant.DIMENSION,
	        column = Constant.DIMENSION,
	        stackLen = this.move_stack.size();
	    
	    int centerRow = (int) Math.floor((row - 1) / 2),
	        centerColumn = (int) Math.floor((column - 1) / 2);
	    if (stackLen==0 || (stackLen == 1 && this.move_board[Util.getIndex(centerRow,centerColumn)].type == Constant.NONE)) {
	        availableSteps.add(Util.getIndex(centerRow,centerColumn));
	        return availableSteps;
	    } else {
	        if (stackLen == 1) {
	            int nextRow = centerRow + (Math.random() < 0.5 ? -1 : 1),
	                nextColumn = centerColumn + (Math.random() < 0.5 ? -1 : 1);
	            availableSteps.add(Util.getIndex(nextRow,nextColumn));
	            return availableSteps;
	        } else {
	            Map<Integer, Boolean> hash = new HashMap<Integer, Boolean>();
	            
	            Iterator<Move> it = move_stack.iterator();
	            while(it.hasNext()){
	            	Move p = it.next();
	            	List<Integer> nearPoints = this.getNearPoints(p);
	            	for(int nearPoint : nearPoints){
	                    if (hash.get(nearPoint) == null) {
	                        availableSteps.add(nearPoint);
	                        hash.put(nearPoint, true);
	                    }
	            	}
	            }
	            
	            return availableSteps;
	        }
	    }
	}

	public void debug(){
		System.out.println("=====st==================");
		System.out.println(this.stateCalc.toString());
		System.out.println("---------------");
	}
	
	public void calcState(){
		//竖
		sb.reset();
		int startIndex = verticalStartPoint[chessIndex];
		for(int i=startIndex; i<=verticalEndPoint[chessIndex];i+=16) {
			sb.append(this.move_board[i].type);
		}		
		StateCalculator.startIndex = startIndex;
		StateCalculator.direction = Constant.DIRECTION_VERTICAL;
		StateCalculator.length = Constant.DIMENSION;
		stateCalc.evaluate();
		
		//横
		sb.reset();
		startIndex = horizonStartPoint[chessIndex];
		for(int i=startIndex; i<=horizonEndPoint[chessIndex];i++) {
			sb.append(this.move_board[i].type);
		}
		StateCalculator.startIndex = startIndex;
		StateCalculator.direction = Constant.DIRECTION_HORIZON;
		stateCalc.evaluate();

		//left up
		sb.reset();
	    startIndex = leftUpStartPoint[chessIndex];
		for(int i=startIndex; i<=leftUpEndPoint[chessIndex];i+=17) {
			sb.append(this.move_board[i].type);
		}
		StateCalculator.startIndex = startIndex;
		StateCalculator.direction = Constant.DIRECTION_LEFTUP;
		StateCalculator.length = move_board[leftUpEndPoint[chessIndex]].row-move_board[startIndex].row+1;
		stateCalc.evaluate();

		//right up
		sb.reset();
		//起点,左下
		startIndex = leftDownStartPoint[chessIndex];
		for(int i=startIndex; i>=leftDownEndPoint[chessIndex];i-=15) {
			sb.append(this.move_board[i].type);
		}
		StateCalculator.startIndex = startIndex;
		StateCalculator.direction = Constant.DIRECTION_LEFTDOWN;
		StateCalculator.length = move_board[startIndex].row-move_board[startIndex].column+1;
		stateCalc.evaluate();
	}
	
	public int vcf() {
		int ret = this.aoTree.vcf_entry();
//		int ret = 0;
		return ret;
	}
	
	//在调用vcf之后调用该方法
	public int getBestMove() {
		int move = this.aoTree.getBestMove();
		return move;
	}
	
	public void printAOTree() {
		this.aoTree.printTree();
	}
	
	//selfType,己方是谁, 也是下一步的行动方. nextChessType,下一步是几方还是对方
	public void vcf_action4AI(int selfType) {
		int rival_type = selfType%2+1;
		int self_alive_four = this.stateCalc.chessCnt[selfType][Constant.ALIVE_FOUR];
		int self_sleep_four = this.stateCalc.chessCnt[selfType][Constant.SLEEP_FOUR];
		//己方成五
		if(self_alive_four + self_sleep_four>0) {
			if(self_alive_four>0) {
				this.stateCalc.getFormPoint(selfType, Constant.ALIVE_FOUR);
				return;
			}
			if(self_sleep_four>0) {
				this.stateCalc.getFormPoint(selfType, Constant.SLEEP_FOUR);
				return;
			}
		}
		
		//阻止对方成五
		int rival_alive_four = this.stateCalc.chessCnt[rival_type][Constant.ALIVE_FOUR];
		int rival_sleep_four = this.stateCalc.chessCnt[rival_type][Constant.SLEEP_FOUR];
		if(rival_alive_four + rival_sleep_four>0) {
			if(rival_alive_four>0) {
				this.stateCalc.getStopPoint(rival_type, Constant.ALIVE_FOUR);
				return;
			}
			if(rival_sleep_four>0) {
				this.stateCalc.getStopPoint(rival_type, Constant.SLEEP_FOUR);
				return;
			}
		}
		
		//由活三形成活四
		int self_alive_three = this.stateCalc.chessCnt[selfType][Constant.ALIVE_THREE];
		if(self_alive_three>0) {
			this.stateCalc.getFormPoint(selfType, Constant.ALIVE_THREE);
			return;
		}
		
		//其他情况调用alpha beta方法
		EvalPosition res = selfType == Constant.BLACK?this.max(4, Integer.MAX_VALUE):this.min(4, Integer.MIN_VALUE); //调成4会有异常
		Constant.ret_Points.reset();
		Constant.ret_Points.append(res.index);
		return;		
	}
	
	//selfType,己方是谁, 也是下一步的行动方. 
	public void vcf_action() {
		int rival_type = nextChessType%2+1;
		int self_alive_four = this.stateCalc.chessCnt[nextChessType][Constant.ALIVE_FOUR];
		int self_sleep_four = this.stateCalc.chessCnt[nextChessType][Constant.SLEEP_FOUR];
		//己方成五
		if(self_alive_four + self_sleep_four>0) {
			if(self_alive_four>0) {
				this.stateCalc.getFormPoint(nextChessType, Constant.ALIVE_FOUR);
				return;
			}
			if(self_sleep_four>0) {
				this.stateCalc.getFormPoint(nextChessType, Constant.SLEEP_FOUR);
				return;
			}
		}
		
		//阻止对方成五
		int rival_alive_four = this.stateCalc.chessCnt[rival_type][Constant.ALIVE_FOUR];
		int rival_sleep_four = this.stateCalc.chessCnt[rival_type][Constant.SLEEP_FOUR];
		if(rival_alive_four + rival_sleep_four>0) {
			if(rival_alive_four>0) {
				this.stateCalc.getStopPoint(rival_type, Constant.ALIVE_FOUR);
				return;
			}
			if(rival_sleep_four>0) {
				this.stateCalc.getStopPoint(rival_type, Constant.SLEEP_FOUR);
				return;
			}
		}
		
		//由活三形成活四
		int self_alive_three = this.stateCalc.chessCnt[nextChessType][Constant.ALIVE_THREE];
		if(self_alive_three>0) {
			this.stateCalc.getFormPoint(nextChessType, Constant.ALIVE_THREE);
			return;
		}
		
		//阻止对方由活三形成活四
		int rival_alive_three = this.stateCalc.chessCnt[rival_type][Constant.ALIVE_THREE];
		if(rival_alive_three>0) {
			int black_sleep_three = this.stateCalc.chessCnt[nextChessType][Constant.SLEEP_THREE];
			if(black_sleep_three>0) {
				
				this.stateCalc.getStopPoint(rival_type, Constant.ALIVE_THREE);
				tmp_Points.copy(Constant.ret_Points);				
				//冲四
				this.stateCalc.getFormPoint(nextChessType, Constant.SLEEP_THREE);
				Constant.ret_Points.add(tmp_Points);				
				return;
			}
			else {
				this.stateCalc.getStopPoint(rival_type, Constant.ALIVE_THREE);
				return;
			}
			
		}
		
		//形成活三
		//TODO  获取的方法有点问题，忽略了X__X形成跳三的情况
		tmp_Points.reset();
		int self_alive_two = this.stateCalc.chessCnt[nextChessType][Constant.ALIVE_TWO];
		int self_sleep_three = this.stateCalc.chessCnt[nextChessType][Constant.SLEEP_THREE];
		if(self_alive_two>0 && self_sleep_three>0) {
			//冲四
			this.stateCalc.getFormPoint(nextChessType, Constant.SLEEP_THREE);
			tmp_Points.copy(Constant.ret_Points);
			
			this.stateCalc.getFormPoint(nextChessType, Constant.ALIVE_TWO);
			Constant.ret_Points.add(tmp_Points);
			return;
		}
		else if(self_alive_two>0){
			this.stateCalc.getFormPoint(nextChessType, Constant.ALIVE_TWO);
			return;
		}
		else if(self_sleep_three>0) {
			//冲四
			this.stateCalc.getFormPoint(nextChessType, Constant.SLEEP_THREE);
			return;
		}
		
		//阻止对方形成活三
		int rival_alive_two = this.stateCalc.chessCnt[rival_type][Constant.ALIVE_TWO];
		if(rival_alive_two>0) {
			//TODO //冲三暂不支持
			this.stateCalc.getFormPoint(rival_type, Constant.ALIVE_TWO);
			return;
		}
		
		//其他情况调用alpha beta方法
		EvalPosition res = nextChessType == Constant.BLACK?this.max(4, Integer.MAX_VALUE):this.min(4, Integer.MIN_VALUE); //调成4会有异常
		Constant.ret_Points.reset();
		Constant.ret_Points.append(res.index);
		return;
		
	}
    
	public int vcf_eval() {
		if( selfType != nextChessType) {
			//主棋与下一步不同
			if(this.stateCalc.chessCnt[selfType][Constant.FIVE]>0)
				return Constant.EVAL_STATE_WIN;
			
			if(this.stateCalc.chessCnt[nextChessType][Constant.ALIVE_FOUR]+this.stateCalc.chessCnt[nextChessType][Constant.SLEEP_FOUR]>0)
				return Constant.EVAL_STATE_NOTWIN;
			
			if(this.stateCalc.chessCnt[selfType][Constant.ALIVE_FOUR]>0 || this.stateCalc.chessCnt[selfType][Constant.SLEEP_FOUR]>1)
				return Constant.EVAL_STATE_WIN;
			
			if(this.stateCalc.chessCnt[nextChessType][Constant.ALIVE_THREE]>0)
				return Constant.EVAL_STATE_NOTWIN;
		}
		else {
			//主棋与下一步相同
			if(this.stateCalc.chessCnt[nextChessType%2+1][Constant.FIVE]>0)
				return Constant.EVAL_STATE_NOTWIN;
			
			if(this.stateCalc.chessCnt[selfType][Constant.ALIVE_FOUR]+this.stateCalc.chessCnt[selfType][Constant.SLEEP_FOUR]>0)
				return Constant.EVAL_STATE_WIN;
			
			if(this.stateCalc.chessCnt[nextChessType%2+1][Constant.ALIVE_FOUR]>0 || this.stateCalc.chessCnt[nextChessType%2+1][Constant.SLEEP_FOUR]>1)
				return Constant.EVAL_STATE_NOTWIN;
			
			if(this.stateCalc.chessCnt[selfType][Constant.ALIVE_THREE]>0)
				return Constant.EVAL_STATE_WIN;
		}
		
		return Constant.EVAL_STATE_NOTYET; //局势不明朗
	}
	
	//局面评估
	public int evaluate() {
		Move latest = current();
		int currentType = latest.type;
		if(currentType == Constant.BLACK) {
			if(this.stateCalc.chessCnt[Constant.BLACK][Constant.FIVE]>0)
				return Constant.MAX_VALUE;
			if(this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_FOUR]+this.stateCalc.chessCnt[Constant.WHITE][Constant.SLEEP_FOUR]>0)
				return Constant.MIN_VALUE;
			if(this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_FOUR]>0||this.stateCalc.chessCnt[Constant.BLACK][Constant.SLEEP_FOUR]>1)
				return Constant.MAX_VALUE;
			if(this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_THREE]>0)
				return Constant.MIN_VALUE;
		}
		else {
			if(this.stateCalc.chessCnt[Constant.WHITE][Constant.FIVE]>0)
				return Constant.MIN_VALUE;
			if(this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_FOUR]+this.stateCalc.chessCnt[Constant.BLACK][Constant.SLEEP_FOUR]>0)
				return Constant.MAX_VALUE;
			if(this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_FOUR]>0||this.stateCalc.chessCnt[Constant.WHITE][Constant.SLEEP_FOUR]>1)
				return Constant.MIN_VALUE;
			if(this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_THREE]>0)
				return Constant.MAX_VALUE;
		}
		
		int maxW = 0, minW = 0;
		if(this.stateCalc.chessCnt[Constant.BLACK][Constant.SLEEP_FOUR]>0 && this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_THREE]>0) {
	    	maxW = Constant.VALUE_SLEEP_FOUR_ALIVE_THREE;
	    }
	    else if(this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_THREE]>1){
	    	maxW = Constant.VALUE_TWO_ALIVE_THREE;
	    }
	    else if(this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_THREE]>0){
	    	maxW = Constant.VALUE_ONE_ALIVE_THREE;
	    }
	    else if(this.stateCalc.chessCnt[Constant.BLACK][Constant.SLEEP_FOUR]>0){
	    	maxW = Constant.VALUE_SLEEP_FOUR;
	    }	    
		maxW += this.stateCalc.chessCnt[Constant.BLACK][Constant.SLEEP_THREE] * Constant.VALUE_SLEEP_THREE
				+ this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_TWO] * Constant.VALUE_ALIVE_TWO
				+ this.stateCalc.chessCnt[Constant.BLACK][Constant.SLEEP_TWO] * Constant.VALUE_SLEEP_TWO
				+ this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_ONE] * Constant.VALUE_ALIVE_ONE;

	    //
		if(this.stateCalc.chessCnt[Constant.WHITE][Constant.SLEEP_FOUR]>0 && this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_THREE]>0) {
	    	minW = Constant.VALUE_SLEEP_FOUR_ALIVE_THREE;
	    }
	    else if(this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_THREE]>1){
	    	minW = Constant.VALUE_TWO_ALIVE_THREE;
	    }
	    else if(this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_THREE]>0){
	    	minW = Constant.VALUE_ONE_ALIVE_THREE;
	    }
	    else if(this.stateCalc.chessCnt[Constant.WHITE][Constant.SLEEP_FOUR]>0){
	    	minW = Constant.VALUE_SLEEP_FOUR;
	    }
	    minW += this.stateCalc.chessCnt[Constant.WHITE][Constant.SLEEP_THREE] * Constant.VALUE_SLEEP_THREE
				+ this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_TWO] * Constant.VALUE_ALIVE_TWO
				+ this.stateCalc.chessCnt[Constant.WHITE][Constant.SLEEP_TWO] * Constant.VALUE_SLEEP_TWO
				+ this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_ONE] * Constant.VALUE_ALIVE_ONE;
	    return maxW - minW;
	}	
	
	//ren
	public boolean isBlackWin(){
		return this.stateCalc.chessCnt[Constant.BLACK][Constant.FIVE]>0;
	}
	
	public boolean isWhiteWin(){
		return this.stateCalc.chessCnt[Constant.WHITE][Constant.FIVE]>0;
	}
	
	//判断black时black已落子
	public boolean isBlackWin4MinMax(){
		if(this.stateCalc.chessCnt[Constant.WHITE][Constant.FIVE]>0)
			return false;		
		if(this.stateCalc.chessCnt[Constant.BLACK][Constant.FIVE]>0)
			return true;		
		if(this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_FOUR]+this.stateCalc.chessCnt[Constant.WHITE][Constant.SLEEP_FOUR]>0)
			return false;		
		if(this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_FOUR]>0||this.stateCalc.chessCnt[Constant.BLACK][Constant.SLEEP_FOUR]>1)
			return true;		
		if(this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_THREE]>0)
			return false;
		return false;
	}
	
	//判断white时white已落子
	public boolean isWhiteWin4MinMax(){
		if(this.stateCalc.chessCnt[Constant.BLACK][Constant.FIVE]>0)
			return false;		
		if(this.stateCalc.chessCnt[Constant.WHITE][Constant.FIVE]>0)
			return true;		
		if(this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_FOUR]+this.stateCalc.chessCnt[Constant.BLACK][Constant.SLEEP_FOUR]>0)
			return false;		
		if(this.stateCalc.chessCnt[Constant.WHITE][Constant.ALIVE_FOUR]>0||this.stateCalc.chessCnt[Constant.WHITE][Constant.SLEEP_FOUR]>1)
			return true;		
		if(this.stateCalc.chessCnt[Constant.BLACK][Constant.ALIVE_THREE]>0)
			return false;
		return false;
	}
	
	public EvalPosition max( int depth, int beta) {
	    //记录优势值，应该下棋的位置
		int index = -17, /* row = -1, column = -1, */alpha = Integer.MIN_VALUE ; //-Infinity
	    //什么都不下，直接返回当前棋盘评估值
	    if (depth == 0) {
	        alpha = evaluate();
	        return new EvalPosition(-17, alpha);
	    } else {
	        //获取每一步可以走的方案
	    	List<Integer> steps = availableSteps();
	        if (steps.size()>0) {
	            //对于每一种走法
	            for (int i = 0, l = steps.size(); i < l; i++) {
	            	int step = steps.get(i);
	                //下棋
	            	GobangBoard.chessIndex = step;
	            	GobangBoard.nextChessType = Constant.BLACK;
	            	StateCalculator.vcfFlag = false;
	                put();
	                //如果已经赢了，则直接下棋，不再考虑对方下棋 isBlackWin4MinMax
	                if (isBlackWin4MinMax()) {
	                    alpha = Constant.MAX_VALUE;
	                    index = step;
	                    //退回上一步下棋
	                    StateCalculator.vcfFlag = false;
	                    rollback();
	                    break;
	                } else {
	                    //考虑对方depth-1步下棋之后的优势值，如果对方没棋可下了，则返回当前棋盘估值
	                	EvalPosition res = min( depth - 1, alpha);
	                	if(res == null){
	                        int w = evaluate();
	                        System.err.println("no pos to put : weight " + w);
	                    }
	                    //退回上一步下棋
	                	StateCalculator.vcfFlag = false;
	                    rollback();
	                    if (res.weight > alpha) {
	                        //选择最大优势的走法
	                        alpha = res.weight;
	                        index = step;
	                    }
	                    //如果人可以获得更好的走法，则AI必然不会选择这一步走法，所以不用再考虑人的其他走法
	                    if (alpha >= beta) {
	                        // log('MAX节点' + l + '个棋局，剪掉了' + (l - 1 - i) + '个MIN棋局');
	                        break;
	                    }
	                }

	            } //for
	            return new EvalPosition(index, alpha);
	        } //存在走法
	        return null;
	    }
	}
	
	public EvalPosition min (int depth, int alpha) {
		int index = -17, /* row = -1, column = -1, */beta = Integer.MAX_VALUE;  //Infinity
	    if (depth == 0) {
	        beta = evaluate();
	        return  new EvalPosition(index, beta);
	    } else {
	        //获取每一步可以走的方案
	    	List<Integer> steps = availableSteps();
	        if (steps.size()>0) {
	            //对于每一种走法
	            for (int i = 0, l = steps.size(); i < l; i++) {
	            	int step = steps.get(i);
	                //下棋
	            	GobangBoard.chessIndex = step;
	            	GobangBoard.nextChessType = Constant.WHITE;
	            	StateCalculator.vcfFlag = false;
	                put();
	                //如果已经赢了，则直接下棋，不再考虑对方下棋 isWhiteWin4MinMax
	                if (isWhiteWin4MinMax()) {
	                    beta = Constant.MIN_VALUE;
	                    index = step;
	                    //退回上一步下棋
	                    StateCalculator.vcfFlag = false;
	                    rollback();
	                    break;
	                } else {
	                    //考虑对方depth-1步下棋之后的优势值，如果对方没棋可下了，则返回当前棋盘估值
	                	EvalPosition res = max(depth - 1, beta);
	                	if(res == null){
	                        int w = evaluate();
	                        System.err.println("no pos to put : weight " + w);
	                    }
	                    //退回上一步下棋
	                	StateCalculator.vcfFlag = false;
	                	rollback();
	                    if (res.weight < beta) {
	                        //选择最大优势的走法
	                        beta = res.weight;
	                        index = step;
	                    }
	                    //如果AI可以获得更好的走法，则人必然不会选择这一步走法，所以不用再考虑AI的其他走法
	                    if (beta <= alpha) {
	                        // log('MIN节点' + l + '个棋局，剪掉了' + (l - 1 - i) + '个MAX棋局');
	                        break;
	                    }
	                }
	            }
            
	            return  new EvalPosition(index, beta);
	        }  //存在走法
	        return null;
	    }
	}
	
}
