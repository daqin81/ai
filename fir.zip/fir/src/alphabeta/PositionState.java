package alphabeta;

import common.Constant;

//棋盘上某个位置的属性(属于哪些类型的进攻,哪些类型的防守)
public class PositionState {
	
	//进攻
	//数组代替
	public LinkNode[] attack_node_array;
	
	public int[] attack_node_cnt_array;
	
	//防御
	public LinkNode[] defense_node_array;
	
	public int[] defense_node_cnt_array;
	
	public PositionState() {
		attack_node_array = new LinkNode[Constant.POSITION_STATE_ARRAY_SIZE];
		attack_node_cnt_array = new int[Constant.POSITION_STATE_ARRAY_SIZE];
		defense_node_array = new LinkNode[Constant.POSITION_STATE_ARRAY_SIZE];
		defense_node_cnt_array = new int[Constant.POSITION_STATE_ARRAY_SIZE];
	}
	
	public void clear() {
		for(int type=0;type<7;type++) {
			attack_node_array[type] = null;
			defense_node_array[type] = null;
			attack_node_cnt_array[type] = 0;
			defense_node_cnt_array[type] = 0;			
		}
	}
	
	//////////////////////////////////
	//copy时使用,运行一次vcf调用一次
	public boolean can_add_attack( int renjuType ) {
		return attack_node_cnt_array[renjuType]==0;
	}
	
	public boolean can_add_defense( int renjuType ) {
		return defense_node_cnt_array[renjuType]==0;
	}

	public void attack( int renjuType,  LinkNode linknode) {
		attack_node_array[renjuType] = linknode;
		attack_node_cnt_array[renjuType]++;
	}
	
	public void defense( int renjuType,  LinkNode linknode) {
		defense_node_array[renjuType] = linknode;
		defense_node_cnt_array[renjuType]++;
	}
	//////////////////////////////////
	
	
	public boolean can_add_attack() {
		return attack_node_cnt_array[StateCalculator.renjuType]==0;
	}
	
	public boolean can_add_defense() {
		return defense_node_cnt_array[StateCalculator.renjuType]==0;
	}
	
	public void attack(LinkNode linknode) {
		attack_node_array[StateCalculator.renjuType] = linknode;
		attack_node_cnt_array[StateCalculator.renjuType]++;
	}
	
	public void defense(LinkNode linknode) {
		defense_node_array[StateCalculator.renjuType] = linknode;
		defense_node_cnt_array[StateCalculator.renjuType]++;
	}
	
	public LinkNode popAttackNode() {
		if(attack_node_cnt_array[StateCalculator.renjuType]==1) {
			attack_node_cnt_array[StateCalculator.renjuType]--;
			return attack_node_array[StateCalculator.renjuType];
		}
		else {
			return null;
		}
	}
	
	public LinkNode popDefenseNode() {
		if(defense_node_cnt_array[StateCalculator.renjuType]==1) {
			defense_node_cnt_array[StateCalculator.renjuType]--;
			return defense_node_array[StateCalculator.renjuType];
		}
		else {
			return null;
		}
	}
	
}
