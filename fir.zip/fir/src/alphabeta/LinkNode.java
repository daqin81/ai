package alphabeta;

//链表的节点,被PositionState,PositionLinkedList用到
public class LinkNode {

	public int position; //row<<4|column
	
	public LinkNode prev;
	
	public LinkNode next;
	
	public int index; //节点在数组中的位置
	
	public LinkNode(int index) {
		this.index = index;
	}

	public void copy(LinkNode srcObj) {
		this.position = srcObj.position;
		this.index = srcObj.index;
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();		
		sb.append("LinkNode [position=" + position);
		sb.append(", index=" + index + ", prev=");
		if(prev==null)
			sb.append("null");
		else
			sb.append(prev.position + " index:" + prev.index);
		sb.append(", next=");
		if(next==null)
			sb.append("null");
		else
			sb.append(next.position + " index:" + next.index);
		sb.append("]");
		return sb.toString();
	}
	
}

