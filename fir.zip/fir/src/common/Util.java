package common;

public class Util {
	
	public static int getRow(int position) {
		return position>>4;
	}
	
	public static int getCol(int position) {
		return position&0x0f;
	}
	
	public static int getIndex(int row, int col) {
		return row<<4|col;
	}
	
}
