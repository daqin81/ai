package common;

import alphabeta.IntArray;

public class Constant {

	public static final int DIMENSION = 15;
	public static final int CHESSCNT = 240; //16*15 一行16
	
	public static final int NONE = 0;
	public static final int BLACK = 1;  //human
	public static final int WHITE = 2;  //AI
	public static final int OUTRANGE = -1; //out range
	
	public static final int MAX_VALUE = 100000;
	public static final int MIN_VALUE = -MAX_VALUE;
	public static final int FIVE_W = MAX_VALUE;
	
//	public static final int VALUE_NOWAY = 30000;  //活4或者是双眠4
	public static final int VALUE_SLEEP_FOUR_ALIVE_THREE = 8000;   //眠4活3
	public static final int VALUE_TWO_ALIVE_THREE = 5000;   //两个活3
	public static final int VALUE_SLEEP_FOUR = 200;    //眠4
	public static final int VALUE_ONE_ALIVE_THREE = 500;    //一个活3
		
	public static final int VALUE_SLEEP_THREE = 20;
	public static final int VALUE_ALIVE_TWO = 10;
	public static final int VALUE_SLEEP_TWO = 5;
	public static final int VALUE_ALIVE_ONE = 1;
	public static final int VALUE_SLEEP_ONE = 0;
	
	public static final int TRUE = 1;
	public static final int FALSE = 0;
	
	public static final int DIRECTION_HORIZON = 0;
	public static final int DIRECTION_VERTICAL = 1;
	public static final int DIRECTION_LEFTUP = 2;
	public static final int DIRECTION_LEFTDOWN = 3;
	
	//棋形
	public static final int  NO_TYPE = 0;
	public static final int  FIVE = 1;
	public static final int  ALIVE_FOUR = 2;
	public static final int  SLEEP_FOUR = 3;
	public static final int  ALIVE_THREE = 4;
	public static final int  SLEEP_THREE = 5;
	public static final int  ALIVE_TWO = 6;
	public static final int  SLEEP_TWO = 7;
	public static final int  ALIVE_ONE = 8;
	public static final int  SLEEP_ONE = 9;
	public static final int  BLOCK = 10;
	
	public static final int  MAX_CHESS_TYPE = 10;
	
	public static final int  POSITION_STATE_ARRAY_SIZE = 7;
	public static final int  POSITION_LINKED_LIST_MAX_SIZE = 30;
	
	public static final int  FORM_STOP_POINT_MAX_SIZE = 20;
	
	//数棋时的状态
	public static final int STATE_INITIAL = 0; //initial
	public static final int STATE_BLACK = 1;  //black
	public static final int STATE_WHITE = 2;  //white
	public static final int STATE_EMPTY = 3;  //blank
	
	//and or tree
	public static final int AND_NODE = 1; //and
	public static final int OR_NODE = 2; //or
	
	//评估状态
	public static final int EVAL_STATE_NOTYET = 0; //未评估或评估未完成
	public static final int EVAL_STATE_NOTWIN = 1; //当前player下,输(lose)或平局(tie)
	public static final int EVAL_STATE_WIN = 2; //当前player下，赢(win)
	
	//探索深度,设为可调,一般到11速度就慢了
	public static int EXPLORE_DEPTH = 9; //先手下5手，后手下4手
	
	public static IntArray ret_Points = new IntArray(60);  //弄成个全局静态量

	public static IntArray formList = new IntArray(Constant.FORM_STOP_POINT_MAX_SIZE);
	public static IntArray stopList = new IntArray(Constant.FORM_STOP_POINT_MAX_SIZE);
	
}
