import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import alphabeta.GobangBoard;
import alphabeta.Move;
import alphabeta.StateCalculator;
import common.Constant;
import common.Util;

//棋盘
public class ChessPanel extends JPanel implements MouseListener {

	private static final long serialVersionUID = 2009553216967364156L;
	public static final int MARGIN = 30;// 边距
	public static final int GRID_SPAN = 35;// 网格间距
	
	public static final int DIAMETER = 30;// 直径
	
	public static Font chessFont = new Font("宋体", Font.PLAIN, 22);
	public static  Color[] chessColor = new Color[] { Color.WHITE, Color.BLACK };
	
	boolean gameOver = false;// 游戏是否结束
	int colIndex, rowIndex;// 当前刚下棋子的索引, x水平坐标(col),y纵坐标(row)

	Image img;
	Image shadows;
	Color colortemp;
	
	private GobangBoard gobangBoard = new GobangBoard();
	
	public ChessPanel() {
//		 setBackground(Color.ORANGE);//设置背景色为橘黄色
		img = Toolkit.getDefaultToolkit().getImage("board.jpg");
		shadows = Toolkit.getDefaultToolkit().getImage("shadows.jpg");
		addMouseListener(this);
		addMouseMotionListener(new MouseMotionListener() {
			public void mouseDragged(MouseEvent e) {

			}

			public void mouseMoved(MouseEvent e) {
				// 将鼠标点击的坐标位置转成网格索引
				int y1 = (e.getX() - MARGIN + GRID_SPAN / 2) / GRID_SPAN;
				int x1 = (e.getY() - MARGIN + GRID_SPAN / 2) / GRID_SPAN;
				// 游戏已经结束不能下
				// 落在棋盘外不能下
				// x，y位置已经有棋子存在，不能下
				if (x1 < 0 || x1 > Constant.DIMENSION || y1 < 0 || y1 > Constant.DIMENSION || gameOver || findChess(x1, y1))
					setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				// 设置成默认状态
				else
					setCursor(new Cursor(Cursor.HAND_CURSOR));

			}
		});
	}

	// 绘制
	public void paintComponent(Graphics g) {
		try {
			super.paintComponent(g);// 画棋盘

			int imgWidth = img.getWidth(this);
			int imgHeight = img.getHeight(this);// 获得图片的宽度与高度
			int FWidth = getWidth();
			int FHeight = getHeight();// 获得窗口的宽度与高度
			int x = (FWidth - imgWidth) / 2;
			int y = (FHeight - imgHeight) / 2;
			g.drawImage(img, x, y, null);

			for (int i = 0; i < Constant.DIMENSION; i++) {// 画横线
				if(i>0)
					g.drawString(Integer.toString(i), MARGIN - 20, MARGIN + i * GRID_SPAN);
				g.drawLine(MARGIN, MARGIN + i * GRID_SPAN, MARGIN + (Constant.DIMENSION - 1) * GRID_SPAN, MARGIN + i * GRID_SPAN);
				if(i>0)
					g.drawString(Integer.toString(i), MARGIN + (Constant.DIMENSION - 1) * GRID_SPAN+10, MARGIN + i * GRID_SPAN);
			}
			for (int i = 0; i < Constant.DIMENSION; i++) {// 画竖线
				g.drawString(Integer.toString(i), MARGIN + i * GRID_SPAN-3, MARGIN-5);
				g.drawLine(MARGIN + i * GRID_SPAN, MARGIN, MARGIN + i * GRID_SPAN, MARGIN + (Constant.DIMENSION - 1) * GRID_SPAN);
				g.drawString(Integer.toString(i), MARGIN + i * GRID_SPAN-3, MARGIN + (Constant.DIMENSION - 1) * GRID_SPAN+15);	
			}

			// 画棋子
			for (int i = 0; i < gobangBoard.getMoveCount(); i++) {
				// 网格交叉点x，y坐标
				Move move = gobangBoard.getMove(i);
				int xPos = move.column * GRID_SPAN + MARGIN;
				int yPos = move.row * GRID_SPAN + MARGIN;
				colortemp = move.type == Constant.BLACK?Color.black : Color.white;
				g.setColor(colortemp);// 设置颜色
				if (colortemp == Color.black) {
					RadialGradientPaint paint = new RadialGradientPaint(xPos - DIAMETER / 2 + 10,
							yPos - DIAMETER / 2 + 30, 8, new float[] { 0f, 1f },
							chessColor);
					((Graphics2D) g).setPaint(paint);
					((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING,
							RenderingHints.VALUE_ANTIALIAS_ON);
					((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
							RenderingHints.VALUE_ALPHA_INTERPOLATION_DEFAULT);

				} else if (colortemp == Color.white) {
					RadialGradientPaint paint = new RadialGradientPaint(xPos - DIAMETER / 2 + 25,
							yPos - DIAMETER / 2 + 10, 70, new float[] { 0f, 1f },
							chessColor);
					((Graphics2D) g).setPaint(paint);
					((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING,
							RenderingHints.VALUE_ANTIALIAS_ON);
					((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
							RenderingHints.VALUE_ALPHA_INTERPOLATION_DEFAULT);

				}

				Ellipse2D e = new Ellipse2D.Float(xPos - DIAMETER / 2, yPos - DIAMETER / 2, 34, 35);
				((Graphics2D) g).fill(e);
				if (colortemp == Color.black) {
					g.setColor(Color.white);
				} else {
					g.setColor(Color.black);
				}
				g.setFont(chessFont);
				g.drawString(Integer.toString(i + 1), xPos - 6, yPos + DIAMETER / 2 - 5);
				// 标记最后一个棋子的红矩形框

				if (i == gobangBoard.getMoveCount() - 1) {// 如果是最后一个棋子
					g.setColor(Color.red);
					g.drawRect(xPos - DIAMETER / 2, yPos - DIAMETER / 2, 34, 35);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void mousePressed(MouseEvent e) {// 鼠标在组件上按下时调用
		try{
			// 游戏结束时，不再能下
			if (gameOver)
				return;
	
			// 将鼠标点击的坐标位置转换成网格索引
			colIndex = (e.getX() - MARGIN + GRID_SPAN / 2) / GRID_SPAN;
			rowIndex = (e.getY() - MARGIN + GRID_SPAN / 2) / GRID_SPAN;
	
			// 落在棋盘外不能下
			if (colIndex < 0 || colIndex >= Constant.DIMENSION || rowIndex < 0 || rowIndex >= Constant.DIMENSION)
				return;
	
			// 如果x，y位置已经有棋子存在，不能下
			if (findChess(colIndex, rowIndex))
				return;
	
			// 如果胜出则给出提示信息，不能继续下棋
			GobangBoard.nextChessType = gobangBoard.getMoveCount()%2==0?Constant.BLACK:Constant.WHITE;
			GobangBoard.chessIndex = Util.getIndex(rowIndex, colIndex);
			StateCalculator.vcfFlag = true;
			gobangBoard.put(); //y坐标方向是棋盘的row(行)方向
	
			repaint();// 通知系统重新绘制
	
			if (gobangBoard.isBlackWin()) {
				String msg = String.format("厉害啊！");
				JOptionPane.showMessageDialog(this, msg);
				gameOver = true;
				return;
			}
						
			////////////////////////////////////////////////////
//			//轮到白棋 //AI下棋
//			GobangBoard.selfType = gobangBoard.current().type == Constant.BLACK?Constant.WHITE:Constant.BLACK;
			GobangBoard.selfType = Constant.WHITE;			
			int vcf_ret = gobangBoard.vcf();
			int res = gobangBoard.getBestMove();
//			this.gobangBoard.printAOTree();	//print tree	
			if(vcf_ret == Constant.EVAL_STATE_WIN && res!=-1) {
//				System.out.println("vcf_ret : " + vcf_ret + " row: " + Util.getRow(move) + " col:" + Util.getCol(move));
			}else {
				gobangBoard.vcf_action4AI(Constant.WHITE);
				res = Constant.ret_Points.get(0);
//				System.out.println("no");				
			}
			int row = Util.getRow(res);
			int col = Util.getCol(res);
			GobangBoard.chessIndex = res;
			GobangBoard.nextChessType = Constant.WHITE;
			StateCalculator.vcfFlag = true;
			gobangBoard.put();			
			rowIndex = row; //y坐标方向是棋盘的row(行)方向
		    colIndex = col;
			
			repaint();// 通知系统重新绘制
	        ////////////////////////////////////////////////////
			
			// 如果胜出则给出提示信息，不能继续下棋
			if (gobangBoard.isWhiteWin()) {
				String msg = String.format("再接再励！");
				JOptionPane.showMessageDialog(this, msg);
				gameOver = true;
				return;
			}
		
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

	// 覆盖mouseListener的方法
	public void mouseClicked(MouseEvent e) {
		// 鼠标按键在组件上单击时调用
	}

	public void mouseEntered(MouseEvent e) {
		// 鼠标进入到组件上时调用
	}

	public void mouseExited(MouseEvent e) {
		// 鼠标离开组件时调用
	}

	public void mouseReleased(MouseEvent e) {
		// 鼠标按钮在组件上释放时调用
	}

	// 在棋子数组中查找是否有索引为x，y的棋子存在
	private boolean findChess(int x, int y) {
		return gobangBoard.findChess(y,x);
	}

	public void restartGame() {		
		gameOver = false; // 是否结束
		gobangBoard.restart();
		repaint();
	}

	// 悔棋
	public void goback() {
		if (gobangBoard.getMoveCount() == 0)
			return;
		gameOver = false;
		if (gobangBoard.getMoveCount()>0) {
			StateCalculator.vcfFlag = true;
			gobangBoard.rollback();  //TODO
		}
		repaint();
	}
	
	//将 //TODO  test
	public void eval() {
		GobangBoard.selfType = gobangBoard.current().type == Constant.BLACK?Constant.WHITE:Constant.BLACK;
		int vcf_ret = gobangBoard.vcf();
		int move = gobangBoard.getBestMove();
//		this.gobangBoard.printAOTree();	//print tree	
		if(vcf_ret > Constant.EVAL_STATE_NOTYET && move!=-1)
			System.out.println("vcf_ret : " + vcf_ret + " row: " + Util.getRow(move) + " col:" + Util.getCol(move));
		else
			System.out.println("no");
//		System.out.println("mov cnt:" +gobangBoard.getMoveCount());
		
	}
	
	// 设置矩形的Dimension
	public Dimension getPreferredSize() {
		return new Dimension(MARGIN * 2 + GRID_SPAN * Constant.DIMENSION, MARGIN * 2 + GRID_SPAN * Constant.DIMENSION);
	}

}