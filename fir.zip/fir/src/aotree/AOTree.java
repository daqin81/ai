package aotree;

import java.util.ArrayList;
import java.util.List;

import alphabeta.GobangBoard;
import alphabeta.IntArray;
import alphabeta.Move;
import alphabeta.StateCalculator;
import common.Constant;

//and or tree
public class AOTree {
	
	public Node root_node = new Node();  //根节点
	
	public GobangBoard gobangBoardOrigin;
	
	public GobangBoard gobangBoard; //使用时临时从origin拷贝，故障隔离，抛异常时不影响整体
	
	public int startType; //计算之前,最后一个的类型
	
	private Node cur_node;
	
	public AOTree(GobangBoard gobangBoardOrigin) {
		this.gobangBoardOrigin = gobangBoardOrigin;
	}
	
	public void resetRootNode() {
		root_node.type = Constant.OR_NODE;
		Move move = this.gobangBoardOrigin.current();
		if(gobangBoard == null)
			gobangBoard = new GobangBoard();//一次初始化，之后拷贝时只拷贝关键数据
		gobangBoard.copy(gobangBoardOrigin);
		startType = move.type;
		root_node.point = move.index;
		root_node.sub_cnt = 0;
		root_node.eval_sub_cnt = 0;
		root_node.eval_state = Constant.EVAL_STATE_NOTYET;
	}
	
	//寻找最好的节点，对于or节点管用
	public int getBestMove() {
		int move = root_node.getBestMove();
		return move;
	}
	
	//求哪方的最优点就用哪方的类型
	public int vcf_entry() {
		resetRootNode();
		this.cur_node = root_node;
		vcf();
		int eval_state = root_node.eval_state;
		return eval_state;
	}
	
	public List<Node> exploreSubNodes(Node cur_node) {
		List<Node> subList = new ArrayList<Node>();
		//设置上下级关系
		IntArray ptlist = Constant.ret_Points;
		int size = ptlist.getSize();
		for(int i=0;i<size;i++) {
			int position = ptlist.get(i);
			Node node = new Node();
			node.point = position;
			node.layer = cur_node.layer+1;
			node.type = cur_node.type == Constant.AND_NODE? Constant.OR_NODE:Constant.AND_NODE;
			//子节点数不考虑
			//子节点被评估数不考虑
			//状态默认为0
			node.super_node = cur_node;
			//子节点数组
			subList.add(node);
		}
		return subList;
	}
	
	//vcf
	public void vcf() {
		try {
		//根据当前节点状态判断,val=2时，对当前节点进行拓展或评估
		if(cur_node.layer<Constant.EXPLORE_DEPTH) {			
			if(cur_node.eval_state==Constant.EVAL_STATE_NOTYET) {
				
				//遇到与发起节点类型相同的节点，即奇数层节点，先评估局面，如果无结果(胜或败)则进行探索，否则结束。
				GobangBoard.nextChessType = (cur_node.layer+this.startType)%2 == Constant.BLACK?Constant.WHITE:Constant.BLACK;
				int eval_val = this.gobangBoard.vcf_eval();
				if(eval_val > Constant.EVAL_STATE_NOTYET) {
					//明显结果,输或者赢时设置状态,并回溯。平局(未分胜负)不计,继续探索
					cur_node.eval_state = eval_val;
					backtracking();
				}
				else {
					if(cur_node.sub_cnt==0) {
						//探索,根据局面找出下一步动作,添加子节点，并选拓展的第一个子节点继续探索
						this.gobangBoard.vcf_action();						
						List<Node> subList = this.exploreSubNodes(cur_node);
						
						//对sub node的上级节点进行设置，深度进行设置，
						cur_node.addSub(subList);
						Node subNode = subList.get(0);						
						//add sub node
						GobangBoard.chessIndex = subNode.point;
						StateCalculator.vcfFlag = true;
						this.gobangBoard.put();
						this.cur_node = subNode;
						vcf();  //深度优先
						this.cur_node = subNode;
					}
					else{
						//选择eval_sub_cnt为索引的节点进行探索或评估
						//是否进行越界判断,当eval_sub_cnt等于size时怎么处理
						Node subNode = cur_node.getNextSubNode();						
						//roll back 当前棋子,add sub node
						StateCalculator.vcfFlag = true;
						this.gobangBoard.rollback();
						GobangBoard.chessIndex = subNode.point;
						StateCalculator.vcfFlag = true;
						this.gobangBoard.put();
						this.cur_node = subNode;
						vcf();  //深度优先
						this.cur_node = subNode;
					}
				}
			}
			else {
				//已评估,向上回溯
				backtracking();
			}
		}
		else {
			//不再进行探索，未评估则进行评估
			if(cur_node.eval_state==Constant.EVAL_STATE_NOTYET) {
				//在拓展达到指定层时,如果出现平局,则也算输,因为需要的最终结果是胜
				GobangBoard.nextChessType = (cur_node.layer+this.startType)%2 == Constant.BLACK?Constant.WHITE:Constant.BLACK;
					int eval_val = this.gobangBoard.vcf_eval();
				if(eval_val == Constant.EVAL_STATE_WIN)
					cur_node.eval_state = eval_val;
				else
					cur_node.eval_state = Constant.EVAL_STATE_NOTWIN;
				backtracking(); //回退
				
			}
			else {
				//已评估,向上回溯
				//TODO 估计应该不会走到该分支
//				System.out.println("xxxxx");
//				backtracking(cur_node, selfType, 4);
			}
		}
		}catch(Exception ex) {			
			ex.printStackTrace();
		}
	}
	
	//回溯
	public void backtracking() {
		try {
		if(cur_node.layer==0)
			return; //已到顶层			
		//roll back
		StateCalculator.vcfFlag = true;
		this.gobangBoard.rollback();
		if(cur_node.type == Constant.OR_NODE) {			
			if(cur_node.eval_state < Constant.EVAL_STATE_WIN) {
				Node superNode = cur_node.super_node;  //上一层节点
				superNode.eval_state = Constant.EVAL_STATE_NOTWIN;  //设置上一层节点为no win
				this.cur_node = superNode;
				vcf(); //评估上一层节点
				this.cur_node = superNode;
			}
			else {
				Node superNode = cur_node.super_node;  //上一层节点
				superNode.eval_sub_cnt++;  //增加上一层节点的已评估数
				Node nextNode = superNode.getNextSubNode();				
				if(nextNode!=null) {
					GobangBoard.nextChessType = this.gobangBoard.current().type== Constant.BLACK?Constant.WHITE:Constant.BLACK;					
					GobangBoard.chessIndex = nextNode.point;
					StateCalculator.vcfFlag = true;
					this.gobangBoard.put();
					this.cur_node = nextNode;
					vcf(); //评估下一个同级节点
					this.cur_node = nextNode;
				}
				else {
					superNode.calcEvalState(); //所有节点评估过了，设置上一级节点的状态
					this.cur_node = superNode;
					backtracking(); //再上一层
					this.cur_node = superNode;
				}
			}
		}
		else if(cur_node.type == Constant.AND_NODE) {
			if(cur_node.eval_state < Constant.EVAL_STATE_WIN) {
				Node superNode = cur_node.super_node;  //上一层节点
				superNode.eval_sub_cnt++;  //增加上一层节点的已评估数
				Node nextNode = superNode.getNextSubNode();
				if(nextNode!=null) {
					GobangBoard.nextChessType = this.gobangBoard.current().type== Constant.BLACK?Constant.WHITE:Constant.BLACK;
					GobangBoard.chessIndex = nextNode.point;
					StateCalculator.vcfFlag = true;
					this.gobangBoard.put();
					this.cur_node = nextNode;
					vcf(); //评估下一个同级节点
					this.cur_node = nextNode;
				}
				else {
					superNode.calcEvalState(); //所有节点评估过了，设置上一级节点的状态
					this.cur_node = superNode;
					backtracking(); //再上一层
					this.cur_node = superNode;
				}
			}
			else {
				Node superNode = cur_node.super_node;  //上一层节点
				superNode.eval_state = Constant.EVAL_STATE_WIN;  //设置上一层节点为 win
				this.cur_node = superNode;
				vcf(); //评估上一层节点
				this.cur_node = superNode;
			}
		}
		}catch(Exception ex) {			
			ex.printStackTrace();
		}
	}
	
	// 打印树, 调用入口
	public void printTree() {
		// 用logger打印在console上
		List<String> leftCh = new ArrayList<String>(); // ' ' └ │ ├ ─
		printTree(this.root_node, leftCh);
	}

	// 打印树节点，递归
	public void printTree(Node node, List<String> leftCh) {
		// 用logger打印在console上
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < leftCh.size(); i++) {
			if (i == (leftCh.size() - 1)) {
				sb.append("  ").append(leftCh.get(i)); // └ ├
			} else if (leftCh.get(i).equals("└")) {
				sb.append("  ").append(" ");
			} else {
				sb.append("  ").append("│");
			}
		}
		sb.append("-");
		sb.append(node.toString());
		System.out.println(sb);

		List<Node> subNodes = node.sub_nodes;
		if(subNodes != null)
		for (int i = 0; i < subNodes.size(); i++) {
			Node subnode = subNodes.get(i);

			if (i == (subNodes.size() - 1)) {
				leftCh.add("└");
			} else {
				leftCh.add("├");
			}
			printTree(subnode, leftCh);
			leftCh.remove(leftCh.size() - 1);
		}
	}
	
}
