package aotree;

import java.util.List;

import common.Constant;
import common.Util;

public class Node {
	
    //当前要下的位置,root的move为null
	public int point;//点的序号
	
	public int layer;  //层数，从0开始
	
	public int type;  //类型  与 或
	
	public int sub_cnt; //子节点数
	
	public int eval_sub_cnt;  //子节点被评估数
	
	public int eval_state;  //评估状态 2(未评估或评估未完成)  0,表示当前player下,输(lose)或平局(tie), 1,表示当前player下，赢(win)
	
	public Node super_node;
	
	public List<Node> sub_nodes;
	
	public Node() {
				
	}
	
	public void calcEvalState() {
		if(sub_nodes!=null) {
			if(this.type == Constant.AND_NODE) {
				boolean winflag = true;
				for(Node node :sub_nodes) {
					if(node.eval_state < Constant.EVAL_STATE_WIN) {
						winflag = false;
						break;
					}
				}
				eval_state = winflag?Constant.EVAL_STATE_WIN:Constant.EVAL_STATE_NOTWIN;
			}
			else {
				boolean loseflag = true;
				for(Node node :sub_nodes) {
					if(node.eval_state == Constant.EVAL_STATE_WIN) {
						loseflag = false;
						break;
					}
				}
				eval_state = loseflag?Constant.EVAL_STATE_NOTWIN:Constant.EVAL_STATE_WIN;
			}
		}
	}
	
	@Override
	public String toString(){
		String eval_state_Str;
		if(eval_state == 2)
			eval_state_Str = "赢";
		else if(eval_state == 1)
			eval_state_Str = "不赢";
		else
			eval_state_Str = "0";
		StringBuffer sb = new StringBuffer();
		sb.append("row:").append(Util.getRow(point)).append(" col:").append(Util.getCol(point))
		.append(type==Constant.AND_NODE?" AND ":" OR ").append(" subCnt:").append(sub_cnt)
		.append(" evalCnt:").append(eval_sub_cnt).append(" evalState: ").append(eval_state_Str);
		return sb.toString();
		
	}
	
	//其他构造方法
	
	//寻找最好的节点，对于or节点管用
	public int getBestMove() {
		int move = eval_sub_cnt == sub_cnt?-1:sub_nodes.get(eval_sub_cnt).point;
		return move;
	}
	
	public void addSub(List<Node> subList) {
		sub_cnt = subList.size();
		sub_nodes = subList;
	}
	
	public Node getNextSubNode() {
		return this.eval_sub_cnt == this.sub_cnt?null:sub_nodes.get(this.eval_sub_cnt);
	}
	
	
}
